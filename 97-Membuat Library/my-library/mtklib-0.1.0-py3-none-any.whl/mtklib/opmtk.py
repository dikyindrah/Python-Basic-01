def penjumlahan(x, y):
    return x + y

def pengurangan(x, y):
    return x - y

def pembagian(x, y):
    return x / y

def perkalian(x, y):
    return x * y